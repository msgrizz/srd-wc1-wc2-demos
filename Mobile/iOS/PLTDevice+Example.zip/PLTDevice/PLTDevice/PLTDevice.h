//
//  PLTDevice.h
//  PLTDevice
//
//  Created by Davis, Morgan on 8/1/13.
//  Copyright (c) 2013 Plantronics, Inc. All rights reserved.
//

#ifndef PLTDevice_PLTDevice_h
#define PLTDevice_PLTDevice_h

#import "PLTDeviceManager.h"

#endif
